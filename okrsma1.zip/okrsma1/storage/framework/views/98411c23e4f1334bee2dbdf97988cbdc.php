<?php $__env->startSection('title',$schedule->exists?'Edit Jadwal':'Jadwal Baru'); ?>
<?php $__env->startSection('content'); ?>
<div class="card p-4">
    <form method="POST" id="scheduleForm" action="<?php echo e($schedule->exists?route('admin.schedules.update',$schedule):route('admin.schedules.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($schedule->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php
        $selectedTeams = old('surgical_team_ids', $schedule->exists ? $schedule->surgicalTeams->pluck('id')->map(fn($id)=>(int)$id)->all() : []);
        $selectedPatient = old('patient_id', $schedule->patient_id);
        $selectedOperator = old('operator_id', $schedule->operator_id);
        $selectedAnesthesia = old('anesthesia_id', $schedule->anesthesia_id);
        ?>

        <div class="row g-3">
            <div class="col-md-5">
                <label class="form-label">Nama Pasien</label>
                <input type="text" id="patient_name" name="patient_name" class="form-control" list="patient_list" placeholder="Ketik atau pilih nama pasien..." autocomplete="off" value="<?php echo e(old('patient_name', $schedule->patient?->name)); ?>" required>
                <input type="hidden" name="patient_id" id="patient_id" value="<?php echo e(old('patient_id', $schedule->patient_id)); ?>">
                <datalist id="patient_list">
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->name); ?>" data-id="<?php echo e($p->id); ?>" data-rm="<?php echo e($p->medical_record_no); ?>" data-gender="<?php echo e($p->gender); ?>"></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
                <div id="patient_hint" class="small-muted mt-1">Jika pasien baru, cukup isi Nama, No. RM, dan Jenis Kelamin lalu langsung Simpan.</div>
            </div>
            <div class="col-md-3">
                <label class="form-label">No. RM</label>
                <input type="text" id="patient_medical_record_no" name="patient_medical_record_no" class="form-control" placeholder="Nomor rekam medis" value="<?php echo e(old('patient_medical_record_no', $schedule->patient?->medical_record_no)); ?>" autocomplete="off">
            </div>
            <div class="col-md-2">
                <label class="form-label">Jenis Kelamin</label>
                <select id="patient_gender" name="patient_gender" class="form-select" required>
                    <option value="">Pilih</option>
                    <option value="P" <?php if(old('patient_gender',$schedule->patient?->gender)==='P'): echo 'selected'; endif; ?>>Perempuan</option>
                    <option value="L" <?php if(old('patient_gender',$schedule->patient?->gender)==='L'): echo 'selected'; endif; ?>>Laki-laki</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Umur</label>
                <input type="text" name="age" id="age" class="form-control" value="<?php echo e(old('age', $patient->age ?? '')); ?>" placeholder="Cth: 35 Tahun atau 5 Bulan">
            </div>
            <div class="col-md-2">
                <label class="form-label">Tanggal Operasi</label>
                <input type="date" name="operation_date" class="form-control" value="<?php echo e(old('operation_date',$schedule->operation_date?->format('Y-m-d')??request('date',now()->toDateString()))); ?>" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Jam</label>
                <input type="time" name="operation_time" class="form-control" value="<?php echo e(old('operation_time', $schedule->operation_time ? substr((string)$schedule->operation_time,0,5) : '')); ?>" required>
            </div>

            <div class="col-md-3">
                <label class="form-label">Ruang Operasi / OK</label>
                <select name="ok_level" class="form-select">
                    <option <?php if(old('ok_level',$schedule->ok_level)==='OK 1'): echo 'selected'; endif; ?>>OK 1</option>
                    <option <?php if(old('ok_level',$schedule->ok_level)==='OK 2'): echo 'selected'; endif; ?>>OK 2</option>
                    <option <?php if(old('ok_level',$schedule->ok_level)==='OK 3'): echo 'selected'; endif; ?>>OK 3</option>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label"><i class="bi bi-clipboard2-pulse me-1 text-primary"></i>Diagnosa</label>
                <input name="diagnosis" id="diagnosis" list="diagnosis_history" class="form-control input-animated" value="<?php echo e(old('diagnosis',$schedule->diagnosis)); ?>" placeholder="Ketik diagnosa..." autocomplete="off">
                <datalist id="diagnosis_history"><?php $__currentLoopData = $diagnosisHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item); ?>"></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></datalist>
            </div>
            <div class="col-md-4">
                <label class="form-label"><i class="bi bi-scissors me-1 text-primary"></i>Tindakan</label>
                <input name="procedure" id="procedure" list="procedure_history" class="form-control input-animated" value="<?php echo e(old('procedure',$schedule->procedure)); ?>" placeholder="Ketik tindakan..." autocomplete="off" required>
                <datalist id="procedure_history"><?php $__currentLoopData = $procedureHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item); ?>"></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></datalist>
            </div>

            <div class="col-md-4">
                <label class="form-label">Operator</label>
                <input type="text" id="operator_search" class="form-control" list="operator_list" placeholder="Pilih atau ketik nama operator..." autocomplete="off" value="<?php echo e($selectedOperator && $operators->firstWhere('id',(int)$selectedOperator) ? $operators->firstWhere('id',(int)$selectedOperator)->name : ''); ?>">
                <input type="hidden" name="operator_id" id="operator_id" value="<?php echo e($selectedOperator); ?>">
                <datalist id="operator_list"><?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($x->name); ?>" data-id="<?php echo e($x->id); ?>"></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></datalist>
                <div id="operator_hint" class="small-muted mt-1">Pilih operator dari daftar.</div>
            </div>
            <div class="col-md-4">
                <label class="form-label">Anestesi</label>
                <input type="text" id="anesthesia_search" class="form-control" list="anesthesia_list" placeholder="Pilih atau ketik nama anestesi..." autocomplete="off" value="<?php echo e($selectedAnesthesia && $anesthesias->firstWhere('id',(int)$selectedAnesthesia) ? $anesthesias->firstWhere('id',(int)$selectedAnesthesia)->name : ''); ?>">
                <input type="hidden" name="anesthesia_id" id="anesthesia_id" value="<?php echo e($selectedAnesthesia); ?>">
                <datalist id="anesthesia_list"><?php $__currentLoopData = $anesthesias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($x->name); ?>" data-id="<?php echo e($x->id); ?>"></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></datalist>
                <div id="anesthesia_hint" class="small-muted mt-1">Pilih anestesi dari daftar.</div>
            </div>

            <div class="col-md-4">
                <label class="form-label">Tim Bedah <span class="text-muted">(pilih atau ketik, tanpa tombol Tambah)</span></label>
                <input type="text" id="team_search" class="form-control" list="team_list" placeholder="Pilih atau ketik nama anggota tim..." autocomplete="off">
                <datalist id="team_list">
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($x->name); ?>" data-id="<?php echo e($x->id); ?>"><?php echo e($x->name); ?> — <?php echo e($x->profession?->name ?? $x->role ?? 'Perawat'); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
                <div id="team_chips" class="border rounded p-2 mt-2" style="min-height:48px">
                    <?php $__currentLoopData = $teams->whereIn('id',$selectedTeams); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge rounded-pill text-bg-primary me-1 mb-1 team-chip" data-id="<?php echo e($x->id); ?>" data-name="<?php echo e($x->name); ?>">
                        <?php echo e($x->name); ?> <small class="opacity-75">(<?php echo e($x->profession?->name ?? $x->role ?? 'Perawat'); ?>)</small>
                        <button type="button" class="btn-close btn-close-white ms-1 remove-team" aria-label="Hapus"></button>
                        <input type="hidden" name="surgical_team_ids[]" value="<?php echo e($x->id); ?>">
                        <input type="hidden" name="surgical_team_names[]" value="<?php echo e($x->name); ?>">
                    </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(empty($selectedTeams)): ?><span id="team_empty" class="text-muted small">Belum ada anggota dipilih.</span><?php endif; ?>
                </div>
                <div class="small-muted mt-1">Ketik nama lalu tekan Enter atau pilih nama dari daftar. Semua anggota baru otomatis disimpan saat tombol Simpan ditekan.</div>
            </div>

            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option <?php if(old('status',$schedule->status)==='Terjadwal'): echo 'selected'; endif; ?>>Terjadwal</option>
                    <option <?php if(old('status',$schedule->status)==='Selesai'): echo 'selected'; endif; ?>>Selesai</option>
                    <option <?php if(old('status',$schedule->status)==='Batal'): echo 'selected'; endif; ?>>Batal</option>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" name="cito" value="1" id="cito" <?php if(old('cito',$schedule->cito)): echo 'checked'; endif; ?>><label class="form-check-label" for="cito">CITO</label></div>
            </div>
            <div class="col-12"><label class="form-label">Catatan</label><textarea name="notes" class="form-control" rows="3"><?php echo e(old('notes',$schedule->notes)); ?></textarea></div>
        </div>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-3 mb-0">
            <div class="fw-bold mb-1"><i class="bi bi-exclamation-triangle me-1"></i> Jadwal belum disimpan</div>
            <ul class="mb-0 ps-3"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
        <?php endif; ?>


        <div class="mt-4 d-flex gap-2"><button type="submit" class="btn btn-rs action-click"><i class="bi bi-check-circle me-1"></i>Simpan</button><a href="<?php echo e(route('admin.schedules.index',['date'=>request('date',$schedule->operation_date?->format('Y-m-d'))])); ?>" class="btn btn-outline-secondary">Batal</a></div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .input-animated {
        transition: box-shadow .2s ease, transform .2s ease, border-color .2s ease
    }

    .input-animated:focus {
        transform: translateY(-1px);
        box-shadow: 0 0 0 .2rem rgba(27, 122, 90, .15);
        border-color: #1b7a5a
    }

    .action-click {
        transition: transform .15s ease, box-shadow .15s ease
    }

    .action-click:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 18px rgba(27, 122, 90, .2)
    }

    .action-click:active {
        transform: scale(.97)
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function() {
        const normalize = s => (s || '').trim().toLowerCase();
        const patientName = document.getElementById('patient_name');
        const patientRM = document.getElementById('patient_medical_record_no');
        const patientGender = document.getElementById('patient_gender');
        const patientId = document.getElementById('patient_id');
        const patientHint = document.getElementById('patient_hint');

        function findPatient() {
            const val = normalize(patientName.value);
            let match = null;
            document.querySelectorAll('#patient_list option').forEach(o => {
                if (normalize(o.value) === val) match = o;
            });
            if (match) {
                patientId.value = match.dataset.id || '';
                if (!patientRM.value) patientRM.value = match.dataset.rm || '';
                if (!patientGender.value) patientGender.value = match.dataset.gender || '';
                patientHint.textContent = 'Pasien ditemukan. Data tetap akan disimpan saat jadwal disimpan.';
                patientHint.className = 'small-muted mt-1 text-success';
            } else {
                patientId.value = '';
                patientHint.textContent = 'Pasien baru? Isi No. RM dan Jenis Kelamin. Tidak perlu menambah data pasien terlebih dahulu.';
                patientHint.className = 'small-muted mt-1';
            }
        }
        patientName.addEventListener('input', findPatient);
        patientName.addEventListener('change', findPatient);
        findPatient();

        function bindSearch(inputId, hiddenId, listId, hintId) {
            const input = document.getElementById(inputId),
                hidden = document.getElementById(hiddenId),
                list = document.getElementById(listId),
                hint = document.getElementById(hintId);
            if (!input) return;

            function find() {
                const val = normalize(input.value);
                let match = null;
                list.querySelectorAll('option').forEach(o => {
                    if (normalize(o.value) === val) match = o;
                });
                hidden.value = match ? match.dataset.id : '';
                if (match) {
                    hint.textContent = 'Data ditemukan.';
                    hint.className = 'small-muted mt-1 text-success';
                } else {
                    hint.textContent = val ? 'Pilih nama yang tersedia di daftar.' : 'Pilih dari daftar.';
                    hint.className = 'small-muted mt-1';
                }
            }
            input.addEventListener('input', find);
            input.addEventListener('change', find);
            input.addEventListener('blur', find);
            find();
        }
        bindSearch('operator_search', 'operator_id', 'operator_list', 'operator_hint');
        bindSearch('anesthesia_search', 'anesthesia_id', 'anesthesia_list', 'anesthesia_hint');

        const teamInput = document.getElementById('team_search'),
            teamList = document.getElementById('team_list'),
            chips = document.getElementById('team_chips');

        function addTeamFromInput() {
            const name = (teamInput.value || '').trim();
            if (!name) return;
            // Allow selecting an existing team OR typing a completely new name.
            let match = null;
            teamList.querySelectorAll('option').forEach(o => {
                if (normalize(o.value) === normalize(name)) match = o;
            });
            const exists = [...chips.querySelectorAll('.team-chip')].some(x => normalize(x.dataset.name) === normalize(name));
            if (exists) {
                teamInput.value = '';
                return;
            }
            document.getElementById('team_empty')?.remove();
            const chip = document.createElement('span');
            chip.className = 'badge rounded-pill text-bg-primary me-1 mb-1 team-chip';
            chip.dataset.id = match ? match.dataset.id : '';
            chip.dataset.name = name;
            const prof = match ? ((match.textContent || '').split(' — ')[1] || 'Petugas') : 'Anggota baru';
            chip.innerHTML = name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + ' <small class="opacity-75">(' + prof.replace(/</g, '&lt;') + ')</small> <button type="button" class="btn-close btn-close-white ms-1 remove-team" aria-label="Hapus"></button>' + (match ? '<input type="hidden" name="surgical_team_ids[]" value="' + match.dataset.id + '">' : '') + '<input type="hidden" name="surgical_team_names[]" value="' + name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;') + '">';
            chips.appendChild(chip);
            teamInput.value = '';
            teamInput.focus();
        }
        teamInput.addEventListener('keydown', e => {
            if (e.key === 'Enter') {
                e.preventDefault();
                addTeamFromInput();
            }
        });
        teamInput.addEventListener('change', () => {
            if (teamInput.value.trim()) addTeamFromInput();
        });
        teamInput.addEventListener('blur', () => {
            if (teamInput.value.trim()) addTeamFromInput();
        });
        chips.addEventListener('click', e => {
            if (e.target.classList.contains('remove-team')) {
                e.target.closest('.team-chip').remove();
                if (!chips.querySelector('.team-chip')) chips.innerHTML = '<span id="team_empty" class="text-muted small">Belum ada anggota dipilih.</span>';
            }
        });

        document.getElementById('scheduleForm').addEventListener('submit', e => {
            if (!patientName.value.trim() || !patientGender.value) {
                e.preventDefault();
                alert('Nama Pasien dan Jenis Kelamin wajib diisi.');
                patientName.focus();
                return false;
            }
            return true;
        });
    })();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\okrsma1\resources\views/admin/schedules/form.blade.php ENDPATH**/ ?>